<?php

// require_once './app/src/User/User.php';
// require_once './app/src/Company/Company.php';

use App\Src\User\User as User;
use App\Src\Company\Company as Company;

// We can autoload manually using https://www.php.net/manual/en/function.spl-autoload-register.php
// The anonymous function registered to spl_autoload_register is called when PHP needs to access a class that has not been defined.
// For example:

spl_autoload_register(function($classToLoad) {
	echo 'Anonymous function registered to spl_autoload_register called for loading ' . $classToLoad . PHP_EOL . PHP_EOL;
    $filePath = __DIR__ . '/' . lcfirst(str_replace('\\', '/', $classToLoad)) . '.php';
	require $filePath;
});

$company = new Company();
$user = new User();

$user->setEmail('chris@test.co');
$company->setName('Test Co.');

echo 'The email ' . $user->getEmail() . ' belongs to ' . $company->getName() . PHP_EOL;
