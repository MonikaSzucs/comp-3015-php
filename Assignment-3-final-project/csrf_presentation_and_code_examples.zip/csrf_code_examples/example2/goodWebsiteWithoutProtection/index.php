<!DOCTYPE html>
<html>
    <header>

    </header>
    <body>
        <form action="getting.php" method="POST">
            <input type="text" name="data"/>
            <input type="submit" value="submit form"/>
        </form>
    </body>
</html>