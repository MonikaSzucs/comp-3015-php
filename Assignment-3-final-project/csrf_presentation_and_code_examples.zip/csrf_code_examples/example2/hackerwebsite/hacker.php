<!DOCTYPE html>
<html>
    <header>

    </header>
    <body>
        hacker site
        <form action="http://localhost:8000/getting.php" method="POST">
            <input type="text" name="data"/>
            <input type="submit" value="submit form"/>
        </form>
    </body>
</html>