<?php

namespace src\Models;

/**
 * @property int $id
 * @property string $email
 * @property string $name
 * @property string $password_digest
 */
class User extends Model {

}
