<?php

namespace src\Models;

/**
 * @property int $id
 * @property string $title
 * @property string $url
 * @property int $author_id
 */
class Article extends Model {

}
