<?php

namespace src\Controllers;

class LogoutController extends Controller
{

	public function logout()
	{
		// TODO
	}
}
