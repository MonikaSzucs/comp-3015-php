<?php

function image(string $filename): string {
	return "/images/$filename";
}
