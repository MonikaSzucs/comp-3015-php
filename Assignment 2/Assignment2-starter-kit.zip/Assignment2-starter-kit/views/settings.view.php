<?php require_once 'header.php'; ?>

<?php require_once 'nav.php' ?>
<div class="mx-auto max-w-4xl sm:px-6 lg:px-8 mt-10">
    <form class="space-y-8" action="/settings" method="post" enctype="multipart/form-data">
        <!-- TODO add settings form inputs -->
    </form>

</div>
