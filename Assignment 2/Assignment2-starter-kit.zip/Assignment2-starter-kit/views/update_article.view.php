<?php require_once 'header.php'; ?>

<body>

	<?php require_once 'nav.php'; ?>

	<div class="grid grid-cols-12 mt-20">

		<form class="space-y-6 col-start-4 col-span-6" action="/articles/update" method="POST">
			<!-- TODO: add form inputs for updating an article -->
			<!-- Note that on page render we should auto-fill the inputs with the correct data based on a query parameter article ID -->
		</form>

	</div>

</body>