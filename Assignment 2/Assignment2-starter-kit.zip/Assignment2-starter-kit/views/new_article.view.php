<?php require_once 'header.php'; ?>

<body>

    <?php require_once 'nav.php'; ?>

    <div class="grid grid-cols-12 mt-20">

        <form class="space-y-6 col-start-4 col-span-6" action="/articles/store" method="POST">
            <!-- TODO: add inputs for article creation -->
        </form>

    </div>

</body>