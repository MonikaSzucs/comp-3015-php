<?php

// This is what happens on registration
$password = 'HelloComp3015@BCIT!';
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
echo "The generated bcrypt hash is: $hash" . PHP_EOL;

// This is what happens on login
$loginPassword = 'HelloComp3015@BCIT!';
echo "Checking if \"$loginPassword\" hashes to $hash" . PHP_EOL;
if (password_verify($loginPassword, $hash)) {
    echo "Correct password. You'll be granted entry!" . PHP_EOL;
} else {
    echo "Wrong password supplied." . PHP_EOL;
}
