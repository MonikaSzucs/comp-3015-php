<?php

namespace src\Models;

require_once 'Model.php';

/**
 * @property int $id
 * @property string $title
 * @property string $body
 * @property string $created_at
 * @property string $updated_at
 */
class Post extends Model {

}
