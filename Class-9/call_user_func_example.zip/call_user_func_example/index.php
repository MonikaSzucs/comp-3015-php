<?php

/**
 * This is a small, one file example of how request-function mapping done by web frameworks functions.
 * This example uses the typical https://www.php.net/manual/en/function.call-user-func-array.php as most PHP frameworks do.
 * 
 * You can run the application using:
 *      php -S localhost:8500
 */

class Request {

    public function method(): string {
		return $_SERVER['REQUEST_METHOD'];
	}

    public function getPath(): bool|string {
		$path = $_SERVER['REQUEST_URI'] ?? '/';
		$position = strpos($path, '?');
		return $position === false ? $path : substr($path, 0, $position);
	}

    // ...

}

class Response {

    private ?string $body;

    public function __construct(?string $body = null) {
        $this->body = $body;
    }

    public function setBody(string $body): Response {
		$this->body = $body;
		return $this;
	}

    public function getBody(): ?string {
        return $this->body;
    }

	public function status(int $statusCode): Response {
		http_response_code($statusCode);
		return $this;
	}

    // ...

}

class Router {

    private Request $request;
    private Response $response;
    private static array $routes = [];

    public function __construct(Request $request, Response $response) {
        $this->request = $request;
        $this->response = $response;
    }

    public static function get(string $path, callable $callable): void {
        self::$routes['GET'][$path] = $callable;
    }

    public static function post(string $path, callable $callable): void {
        self::$routes['POST'][$path] = $callable;
    }

    public static function put(string $path, callable $callable): void {
        self::$routes['PUT'][$path] = $callable;
    }

    public static function delete(string $path, callable $callable): void {
        self::$routes['DELETE'][$path] = $callable;
    }

    public function resolve(): Response {
        $path = $this->request->getPath();
		$method = $this->request->method();
		$callback = self::$routes[$method][$path] ?? false;
        if ($callback) {
            $this->response = call_user_func($callback, []);
        }
        else {
            // A route wasn't found for the given request. Return a 404.
            $this->response = (new Response())->status(404);
        }
        return $this->response;
    }
}

class PostsController {

    public function index(): Response {
        return new Response("Index function. If we get here, then call_user_func worked!");
    }

}

class Application {

    private Router $router;
	private Request $request;
	private Response $response;

    public function __construct() {
        $this->request = new Request();
		$this->response = new Response('');
        $this->router = new Router($this->request, $this->response);
    }

    public function run(): void {
        $response = $this->router->resolve();
        echo $response->getBody();
    }

}

Router::get('/', [new PostsController(), 'index']);
(new Application())->run();
