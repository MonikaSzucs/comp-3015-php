This is a toy client application to interact with a web API

Run it:

```
php -S localhost:3000
```
