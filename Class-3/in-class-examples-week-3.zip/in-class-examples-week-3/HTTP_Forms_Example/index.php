<!doctype html>
<html lang="en">
<?php require_once 'layout/header.php' ?>
<body>
<?php require_once 'layout/navigation.php' ?>
<div class="container mx-auto mt-10">
    <h1 class="font-bold">This application provides examples of using forms to accept input.</h1>
    <p>This is the index page (index.php).</p>
</div>
</body>
</html>
