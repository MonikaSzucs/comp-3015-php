<?php

// Handle article deletion and redirecting back to the index page
